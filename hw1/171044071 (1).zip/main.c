/* CELEBR03

   This example opens a file and reads input.

 */
#define _GNU_SOURCE
#define _POSIX_SOURCE
#include <fcntl.h>
#include <unistd.h>
#undef _POSIX_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

//remove braces
char* removeBraces(char * strd){


    char* strnew;
    strnew = malloc(sizeof ( strlen(strd)));
    int len = strlen(strd) -2;
    while('\0' != *strd ){

        if(*strd == '[' || *strd == ']'){
            strd++;
        }
        *strnew = *strd;
        strnew++;
        strd++;
    }
    *strnew = '\0';
    strnew-= len;

   return  strnew;
}

int countBracesword(char *strd){

    char* strnew;
    strnew = malloc(2*sizeof ( strlen(strd)));

    strcpy(strnew,strd);
    int counter =0;

    while('\0' != *strnew ){

        if(']' == * strnew){
            return counter;
        }

        counter++;
        strnew++;

    }
    return -1;

}
// Function to replace a string with another
// string
char* replaceWord(const char* s, const char* oldW,
                  const char* newW, bool insensivitive)
{
    char* result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++) {
        if (strstr(&s[i], oldW) == &s[i]) {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char*)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;

    //if it is insesivitive enter here
    if(insensivitive == true){
        while (*s) {
            // compare the substring with the result
            if (strcasestr(s, oldW) == s) {
                strcpy(&result[i], newW);
                i += newWlen;
                s += oldWlen;
            }
            else
                result[i++] = *s++;
        }


    }
    else if(insensivitive == false){
        while (*s) {
            // compare the substring with the result
            if (strstr(s, oldW) == s) {
                strcpy(&result[i], newW);
                i += newWlen;
                s += oldWlen;
            }
            else
                result[i++] = *s++;
        }
    }

    result[i] = '\0';
    return result;
}


int main(int argc, char *argv[]) {
   // printf("%s\n %s\n %s\n",argv[0],argv[1],argv[2]);

    //parse inputs
    //char str[80] = "This is - www.tutorialspoint.com - website";



    char string1[10][50];
    bool insesivitive = false;
    const char *s = "/";
    int counter =0;

    /* get the first token */
    //printf("%s\n",argv[1]);


    char *token = strtok(argv[1], s);


    /* walk through other tokens */
    while( token != NULL ) {

        //strcpy(string1[counter],token);

        //printf( " %s\n", token );

        if( strcmp(string1[2],"i;") )
        {
            insesivitive =true;
        }
        token = strtok(NULL, s);
        counter++;
    }


   // printf("%s %s %s %s",string1[0],string1[1],string1[2],string1[3]);
   // printf("%d",counter);



    int ret, fd;
    char buf[1024] = {0};
    int i=0;
    size_t total_num_of_char;


    //find the total number of char on the given files


    fd = open("input.txt"   , O_RDWR );
    if (fd < 0) {
        perror("open() error");
        return ret;
    }
    while ((ret = read(fd, buf, sizeof(buf)-1)) > 0) {
        //printf("%s", buf);
        i++;
    }

    //printf("\n");
    total_num_of_char = strlen(buf);
    printf("i=%d  - total number of char = strlen(buf)=%zu\n", i, total_num_of_char);


    char *lines = (char *) malloc(total_num_of_char * sizeof(char));
    memset(lines, 0, total_num_of_char * sizeof(char));
    lseek(fd, 0, SEEK_SET);
    i = 0;

    while ((ret = read(fd, buf, sizeof(buf)-1)) > 0)
    {
        // printf("ret: %d",ret);
        //printf("buf:%s", buf);
        memcpy(lines + (1024 * i), buf, total_num_of_char);
        i++;
    }


    if(counter == 2){
        if(string1[0][0] == '['){

            //d) [zs]tr1 part
            int braceword = countBracesword(string1[0]) -1;

            printf("%s %d",removeBraces(string1[0]) , braceword);
            for(int i =0; i<braceword;i++){
                replaceWord(buf,string1[0],string1[1],false);
               // string1[0]*;
            }

        }
        //normal
        printf("%s",replaceWord(buf,string1[0],string1[1],insesivitive));
    }
    else if( counter == 5){

        //if two times
        //send two times
        printf("insensivitive %d",insesivitive);
        printf("%s",replaceWord(buf,string1[0],string1[3],insesivitive));
        printf("%s",replaceWord(buf,string1[1],string1[4],insesivitive));

    }




    write(fd,buf,sizeof (buf)-1);
    printf("%s\n",buf);
    printf("----------------------------\n");
    printf("strlen(lines):%s", &lines[1024]);

    free(lines);
    //free(s);
    free(token);
    close(fd);
    //unlink("ls.output");
    return ret;
}